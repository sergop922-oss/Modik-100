package com.randomdiseases;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = RandomDiseases.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
class ClientModEvents {
    static final KeyMapping OPEN_MENU = new KeyMapping("key.randomdiseases.open_menu",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.categories.randomdiseases");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU);
    }
}

@Mod.EventBusSubscriber(modid = RandomDiseases.MODID, value = Dist.CLIENT)
class ClientForgeEvents {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && ClientModEvents.OPEN_MENU.consumeClick()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.screen == null) mc.setScreen(new DiseaseScreen());
        }
    }

    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        GuiGraphics g = event.getGuiGraphics();
        int seconds = ClientDiseaseState.ticksToNext() / 20;
        g.drawString(mc.font, String.format("Следующая болезнь: %02d:%02d", seconds / 60, seconds % 60),
                6, 6, 0xFFFFFF, true);
        int y = 18;
        for (String id : ClientDiseaseState.diseases()) {
            DiseaseCatalog.Disease d = DiseaseCatalog.byId(id);
            if (d != null && y < 100) {
                g.drawString(mc.font, "• " + d.name(), 6, y, 0xFFAAAA, true);
                y += 11;
            }
        }
    }
}

class DiseaseScreen extends Screen {
    protected DiseaseScreen() {
        super(Component.literal("Болезни и лечение"));
    }

    @Override
    protected void init() {
        int y = 38;
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                Component.literal("Закрыть"), b -> onClose())
                .bounds(width / 2 - 50, height - 32, 100, 20).build());

        if (ClientDiseaseState.diseases().isEmpty()) {
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                    Component.literal("Болезней пока нет"), b -> {})
                    .bounds(width / 2 - 100, y, 200, 20).build());
            return;
        }

        int shown = 0;
        for (String id : ClientDiseaseState.diseases()) {
            if (shown >= 8) break;
            DiseaseCatalog.Disease d = DiseaseCatalog.byId(id);
            if (d == null) continue;
            String label = d.name() + " — " + d.tier().price + " алм.";
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                    Component.literal(label), b ->
                            NetworkHandler.CHANNEL.sendToServer(new TreatDiseasePacket(d.id())))
                    .bounds(width / 2 - 145, y, 290, 20).build());
            y += 24;
            shown++;
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
        graphics.drawCenteredString(font, "Лечение требует алмазы из инвентаря", width / 2, height - 48, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
