package com.randomdiseases;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(RandomDiseases.MODID)
public class RandomDiseases {
    public static final String MODID = "randomdiseases";
    public static final Logger LOGGER = LogUtils.getLogger();

    public RandomDiseases() {
        NetworkHandler.register();
        LOGGER.info("RandomDiseases: 100 Diseases Edition loaded");
    }
}
