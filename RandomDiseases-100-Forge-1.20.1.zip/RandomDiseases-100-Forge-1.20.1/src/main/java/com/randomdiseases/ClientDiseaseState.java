package com.randomdiseases;

import java.util.List;

public final class ClientDiseaseState {
    private static List<String> diseases = List.of();
    private static int ticksToNext = 2400;

    private ClientDiseaseState() {}

    public static void set(List<String> ids, int ticks) {
        diseases = List.copyOf(ids);
        ticksToNext = Math.max(0, ticks);
    }

    public static List<String> diseases() { return diseases; }
    public static int ticksToNext() { return ticksToNext; }
}
