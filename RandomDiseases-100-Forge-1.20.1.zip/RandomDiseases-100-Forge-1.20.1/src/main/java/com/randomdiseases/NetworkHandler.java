package com.randomdiseases;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.SimpleChannel;

public final class NetworkHandler {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RandomDiseases.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);

    private static boolean registered = false;

    private NetworkHandler() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, TreatDiseasePacket.class,
                TreatDiseasePacket::encode, TreatDiseasePacket::decode, TreatDiseasePacket::handle);
        CHANNEL.registerMessage(1, SyncDiseasesPacket.class,
                SyncDiseasesPacket::encode, SyncDiseasesPacket::decode, SyncDiseasesPacket::handle);
    }
}
