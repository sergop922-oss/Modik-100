package com.randomdiseases;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SyncDiseasesPacket {
    public final List<String> diseases;
    public final int ticksToNext;

    public SyncDiseasesPacket(List<String> diseases, int ticksToNext) {
        this.diseases = List.copyOf(diseases);
        this.ticksToNext = ticksToNext;
    }

    public static void encode(SyncDiseasesPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.diseases.size());
        for (String id : packet.diseases) buf.writeUtf(id, 64);
        buf.writeVarInt(packet.ticksToNext);
    }

    public static SyncDiseasesPacket decode(FriendlyByteBuf buf) {
        int size = Math.min(buf.readVarInt(), 100);
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < size; i++) ids.add(buf.readUtf(64));
        return new SyncDiseasesPacket(ids, buf.readVarInt());
    }

    public static void handle(SyncDiseasesPacket packet, Supplier<NetworkEvent.Context> supplier) {
        supplier.get().enqueueWork(() -> {
            if (Minecraft.getInstance().player != null) {
                ClientDiseaseState.set(packet.diseases, packet.ticksToNext);
            }
        });
        supplier.get().setPacketHandled(true);
    }
}
