package com.randomdiseases;

import java.util.List;

public final class DiseaseCatalog {
    private DiseaseCatalog() {}

    public enum Tier {
        VERY_SEVERE(60, "Очень тяжёлая"),
        SEVERE(45, "Тяжёлая"),
        MEDIUM(35, "Средняя"),
        LIGHT(20, "Лёгкая");

        public final int price;
        public final String displayName;
        Tier(int price, String displayName) {
            this.price = price;
            this.displayName = displayName;
        }
    }

    public enum Mechanic {
        OFFHAND, NO_SPRINT, SLOW, HALF_SCREEN, EAR_BLACKOUT, WEAKNESS,
        COUGH, LONGER_EFFECTS, BLACKOUT, DARKNESS, NAUSEA, HUNGER,
        MIGRAINE, BLINDNESS, NO_JUMP, MINING_FATIGUE, SNEEZE
    }

    public record Disease(String id, String name, Tier tier, Mechanic mechanic) {}

    public static final List<Disease> ALL = List.of(
        new Disease("lost_left_arm", "Синдром потери левой руки", Tier.VERY_SEVERE, Mechanic.OFFHAND),
        new Disease("lost_right_leg", "Синдром потери правой ноги", Tier.VERY_SEVERE, Mechanic.NO_SPRINT),
        new Disease("lost_both_legs", "Синдром потери обеих ног", Tier.VERY_SEVERE, Mechanic.SLOW),
        new Disease("lost_right_eye", "Синдром потери правого глаза", Tier.VERY_SEVERE, Mechanic.HALF_SCREEN),
        new Disease("lost_ear", "Синдром потери уха", Tier.VERY_SEVERE, Mechanic.EAR_BLACKOUT),
        new Disease("heart_failure", "Тяжёлая сердечная недостаточность", Tier.VERY_SEVERE, Mechanic.WEAKNESS),
        new Disease("lung_damage", "Тяжёлое поражение лёгких", Tier.VERY_SEVERE, Mechanic.COUGH),
        new Disease("neurodegenerative", "Нейродегенеративный синдром", Tier.VERY_SEVERE, Mechanic.NO_SPRINT),
        new Disease("immunodeficiency", "Тяжёлый иммунодефицит", Tier.VERY_SEVERE, Mechanic.LONGER_EFFECTS),
        new Disease("fainting", "Синдром частых обмороков", Tier.VERY_SEVERE, Mechanic.BLACKOUT),
        new Disease("severe_seizure", "Тяжёлая эпилепсия (игровая версия)", Tier.VERY_SEVERE, Mechanic.DARKNESS),
        new Disease("coordination_loss", "Синдром потери координации", Tier.VERY_SEVERE, Mechanic.NAUSEA),
        new Disease("respiratory_failure", "Тяжёлая дыхательная недостаточность", Tier.VERY_SEVERE, Mechanic.COUGH),
        new Disease("balance_disorder", "Синдром нарушения равновесия", Tier.VERY_SEVERE, Mechanic.NAUSEA),
        new Disease("metabolic_syndrome", "Тяжёлый метаболический синдром", Tier.VERY_SEVERE, Mechanic.HUNGER),
        new Disease("parkinsons", "Болезнь Паркинсона", Tier.SEVERE, Mechanic.SLOW),
        new Disease("severe_asthma", "Тяжёлая бронхиальная астма", Tier.SEVERE, Mechanic.COUGH),
        new Disease("copd", "Тяжёлая форма ХОБЛ", Tier.SEVERE, Mechanic.NO_SPRINT),
        new Disease("frequent_migraine", "Мигрень с частыми приступами", Tier.SEVERE, Mechanic.MIGRAINE),
        new Disease("severe_anemia", "Тяжёлая анемия", Tier.SEVERE, Mechanic.WEAKNESS),
        new Disease("pneumonia", "Пневмония", Tier.SEVERE, Mechanic.COUGH),
        new Disease("severe_bronchitis", "Тяжёлый бронхит", Tier.SEVERE, Mechanic.COUGH),
        new Disease("severe_allergy", "Тяжёлая аллергическая реакция", Tier.SEVERE, Mechanic.DARKNESS),
        new Disease("severe_vision", "Тяжёлое нарушение зрения", Tier.SEVERE, Mechanic.BLINDNESS),
        new Disease("severe_hearing", "Тяжёлое нарушение слуха", Tier.SEVERE, Mechanic.EAR_BLACKOUT),
        new Disease("vertigo", "Синдром сильного головокружения", Tier.SEVERE, Mechanic.NAUSEA),
        new Disease("arrhythmia", "Нарушение сердечного ритма", Tier.SEVERE, Mechanic.WEAKNESS),
        new Disease("severe_arthritis", "Тяжёлый артрит", Tier.SEVERE, Mechanic.NO_JUMP),
        new Disease("muscle_weakness", "Синдром мышечной слабости", Tier.SEVERE, Mechanic.WEAKNESS),
        new Disease("severe_insomnia", "Тяжёлая бессонница", Tier.SEVERE, Mechanic.DARKNESS),
        new Disease("disorientation", "Синдром потери ориентации", Tier.SEVERE, Mechanic.NAUSEA),
        new Disease("high_fever", "Тяжёлая лихорадка", Tier.SEVERE, Mechanic.NAUSEA),
        new Disease("gastroenteritis", "Тяжёлый гастроэнтерит", Tier.SEVERE, Mechanic.HUNGER),
        new Disease("memory_disorder", "Синдром нарушения памяти", Tier.SEVERE, Mechanic.DARKNESS),
        new Disease("severe_dermatitis", "Тяжёлый дерматит", Tier.SEVERE, Mechanic.WEAKNESS),
        new Disease("sensitivity", "Синдром повышенной чувствительности", Tier.SEVERE, Mechanic.DARKNESS),
        new Disease("neuralgia", "Тяжёлая невралгия", Tier.SEVERE, Mechanic.WEAKNESS),
        new Disease("breathing_disorder", "Синдром нарушенного дыхания", Tier.SEVERE, Mechanic.NO_SPRINT),
        new Disease("severe_rhinitis", "Тяжёлая форма аллергического ринита", Tier.SEVERE, Mechanic.SNEEZE),
        new Disease("hand_coordination", "Синдром нарушения координации рук", Tier.SEVERE, Mechanic.MINING_FATIGUE),
        new Disease("gastritis", "Гастрит", Tier.MEDIUM, Mechanic.HUNGER),
        new Disease("ulcer", "Язва желудка", Tier.MEDIUM, Mechanic.WEAKNESS),
        new Disease("osteochondrosis", "Остеохондроз", Tier.MEDIUM, Mechanic.SLOW),
        new Disease("varicose", "Варикоз", Tier.MEDIUM, Mechanic.NO_SPRINT),
        new Disease("rheumatoid_arthritis", "Ревматоидный артрит", Tier.MEDIUM, Mechanic.NO_JUMP),
        new Disease("allergic_rhinitis", "Аллергический ринит", Tier.MEDIUM, Mechanic.SNEEZE),
        new Disease("conjunctivitis", "Конъюнктивит", Tier.MEDIUM, Mechanic.BLINDNESS),
        new Disease("hives", "Крапивница", Tier.MEDIUM, Mechanic.DARKNESS),
        new Disease("insomnia", "Бессонница", Tier.MEDIUM, Mechanic.DARKNESS),
        new Disease("sinusitis", "Синусит", Tier.MEDIUM, Mechanic.NAUSEA),
        new Disease("tonsillitis", "Тонзиллит", Tier.MEDIUM, Mechanic.COUGH),
        new Disease("pharyngitis", "Фарингит", Tier.MEDIUM, Mechanic.COUGH),
        new Disease("laryngitis", "Ларингит", Tier.MEDIUM, Mechanic.NO_SPRINT),
        new Disease("otitis", "Отит", Tier.MEDIUM, Mechanic.EAR_BLACKOUT),
        new Disease("hypotension", "Гипотония", Tier.MEDIUM, Mechanic.WEAKNESS),
        new Disease("hypertension", "Гипертония", Tier.MEDIUM, Mechanic.DARKNESS),
        new Disease("hypoglycemia", "Гипогликемия", Tier.MEDIUM, Mechanic.HUNGER),
        new Disease("vitamin_d_deficiency", "Дефицит витамина D", Tier.MEDIUM, Mechanic.WEAKNESS),
        new Disease("iron_deficiency", "Дефицит железа", Tier.MEDIUM, Mechanic.WEAKNESS),
        new Disease("magnesium_deficiency", "Дефицит магния", Tier.MEDIUM, Mechanic.NO_JUMP),
        new Disease("muscle_spasm", "Мышечный спазм", Tier.MEDIUM, Mechanic.NO_SPRINT),
        new Disease("neuritis", "Неврит", Tier.MEDIUM, Mechanic.DARKNESS),
        new Disease("tendinitis", "Тендинит", Tier.MEDIUM, Mechanic.MINING_FATIGUE),
        new Disease("bursitis", "Бурсит", Tier.MEDIUM, Mechanic.SLOW),
        new Disease("dyspepsia", "Диспепсия", Tier.MEDIUM, Mechanic.HUNGER),
        new Disease("colitis", "Колит", Tier.MEDIUM, Mechanic.WEAKNESS),
        new Disease("dry_eye", "Синдром сухого глаза", Tier.MEDIUM, Mechanic.BLINDNESS),
        new Disease("tinnitus", "Тиннитус", Tier.MEDIUM, Mechanic.EAR_BLACKOUT),
        new Disease("rhinitis", "Ринит", Tier.MEDIUM, Mechanic.SNEEZE),
        new Disease("motion_sickness", "Синдром укачивания", Tier.MEDIUM, Mechanic.NAUSEA),
        new Disease("common_cold", "Обычная простуда", Tier.LIGHT, Mechanic.SNEEZE),
        new Disease("mild_cough", "Лёгкий кашель", Tier.LIGHT, Mechanic.COUGH),
        new Disease("runny_nose", "Насморк", Tier.LIGHT, Mechanic.SLOW),
        new Disease("mild_migraine", "Лёгкая мигрень", Tier.LIGHT, Mechanic.MIGRAINE),
        new Disease("mild_allergy", "Лёгкая аллергия", Tier.LIGHT, Mechanic.DARKNESS),
        new Disease("fatigue", "Усталость", Tier.LIGHT, Mechanic.WEAKNESS),
        new Disease("mild_insomnia", "Лёгкая бессонница", Tier.LIGHT, Mechanic.DARKNESS),
        new Disease("mild_bronchitis", "Лёгкий бронхит", Tier.LIGHT, Mechanic.COUGH),
        new Disease("mild_gastritis", "Лёгкий гастрит", Tier.LIGHT, Mechanic.HUNGER),
        new Disease("mild_dizziness", "Лёгкое головокружение", Tier.LIGHT, Mechanic.NAUSEA),
        new Disease("mild_conjunctivitis", "Лёгкий конъюнктивит", Tier.LIGHT, Mechanic.BLINDNESS),
        new Disease("mild_sinusitis", "Лёгкий синусит", Tier.LIGHT, Mechanic.NAUSEA),
        new Disease("mild_pharyngitis", "Лёгкий фарингит", Tier.LIGHT, Mechanic.COUGH),
        new Disease("mild_dermatitis", "Лёгкий дерматит", Tier.LIGHT, Mechanic.DARKNESS),
        new Disease("muscle_soreness", "Лёгкая мышечная боль", Tier.LIGHT, Mechanic.SLOW),
        new Disease("mild_neuralgia", "Лёгкая невралгия", Tier.LIGHT, Mechanic.WEAKNESS),
        new Disease("mild_otitis", "Лёгкий отит", Tier.LIGHT, Mechanic.EAR_BLACKOUT),
        new Disease("mild_anemia", "Лёгкая анемия", Tier.LIGHT, Mechanic.WEAKNESS),
        new Disease("mild_hypotension", "Лёгкая гипотония", Tier.LIGHT, Mechanic.DARKNESS),
        new Disease("mild_hypertension", "Лёгкая гипертония", Tier.LIGHT, Mechanic.WEAKNESS),
        new Disease("mild_nausea", "Лёгкая тошнота", Tier.LIGHT, Mechanic.NAUSEA),
        new Disease("mild_allergic_reaction", "Лёгкая аллергическая реакция", Tier.LIGHT, Mechanic.SNEEZE),
        new Disease("mild_arthritis", "Лёгкий артрит", Tier.LIGHT, Mechanic.SLOW),
        new Disease("mild_rhinitis", "Лёгкий ринит", Tier.LIGHT, Mechanic.SNEEZE),
        new Disease("mild_vitamin_deficiency", "Лёгкий дефицит витаминов", Tier.LIGHT, Mechanic.WEAKNESS),
        new Disease("mild_muscle_spasm", "Лёгкий мышечный спазм", Tier.LIGHT, Mechanic.NO_SPRINT),
        new Disease("eye_strain", "Лёгкая усталость глаз", Tier.LIGHT, Mechanic.BLINDNESS),
        new Disease("back_pain", "Лёгкая боль в спине", Tier.LIGHT, Mechanic.SLOW),
        new Disease("mild_balance_disorder", "Лёгкое нарушение равновесия", Tier.LIGHT, Mechanic.NAUSEA),
        new Disease("mild_sleep_disorder", "Лёгкое нарушение сна", Tier.LIGHT, Mechanic.WEAKNESS)
    );

    public static Disease byId(String id) {
        return ALL.stream().filter(d -> d.id().equals(id)).findFirst().orElse(null);
    }
}
