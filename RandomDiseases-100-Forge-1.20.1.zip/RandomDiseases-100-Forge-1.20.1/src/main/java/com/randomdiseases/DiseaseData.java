package com.randomdiseases;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

public final class DiseaseData {
    private static final String KEY = "RandomDiseases100";
    private static final String DISEASES = "Diseases";
    private static final String TIMER = "TicksToNext";

    private DiseaseData() {}

    private static CompoundTag root(ServerPlayer player) {
        CompoundTag parent = player.getPersistentData();
        if (!parent.contains(KEY)) {
            CompoundTag data = new CompoundTag();
            data.put(DISEASES, new ListTag());
            data.putInt(TIMER, 2400);
            parent.put(KEY, data);
        }
        return parent.getCompound(KEY);
    }

    public static List<String> get(ServerPlayer player) {
        ListTag list = root(player).getList(DISEASES, 8);
        List<String> result = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) result.add(list.getString(i));
        return result;
    }

    public static boolean has(ServerPlayer player, String id) {
        return get(player).contains(id);
    }

    public static void add(ServerPlayer player, String id) {
        if (has(player, id)) return;
        root(player).getList(DISEASES, 8).add(StringTag.valueOf(id));
        sync(player);
    }

    public static void remove(ServerPlayer player, String id) {
        ListTag old = root(player).getList(DISEASES, 8);
        ListTag replacement = new ListTag();
        for (int i = 0; i < old.size(); i++) {
            if (!old.getString(i).equals(id)) replacement.add(StringTag.valueOf(old.getString(i)));
        }
        root(player).put(DISEASES, replacement);
        sync(player);
    }

    public static int timer(ServerPlayer player) {
        return root(player).getInt(TIMER);
    }

    public static void timer(ServerPlayer player, int value) {
        root(player).putInt(TIMER, value);
    }

    public static void sync(ServerPlayer player) {
        NetworkHandler.CHANNEL.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
                new SyncDiseasesPacket(get(player), timer(player)));
    }
}
