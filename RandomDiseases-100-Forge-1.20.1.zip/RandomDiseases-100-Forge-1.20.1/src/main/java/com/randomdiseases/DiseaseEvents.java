package com.randomdiseases;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.Random;

@Mod.EventBusSubscriber(modid = RandomDiseases.MODID)
public class DiseaseEvents {
    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;

        int timer = DiseaseData.timer(player) - 1;
        if (timer <= 0) {
            List<String> active = DiseaseData.get(player);
            if (active.size() < DiseaseCatalog.ALL.size()) {
                List<DiseaseCatalog.Disease> available = DiseaseCatalog.ALL.stream()
                        .filter(d -> !active.contains(d.id())).toList();
                DiseaseCatalog.Disease chosen = available.get(RANDOM.nextInt(available.size()));
                DiseaseData.add(player, chosen.id());
                player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                        "Новая болезнь: " + chosen.name()), false);
            }
            timer = 2400;
        }
        DiseaseData.timer(player, timer);

        for (String id : DiseaseData.get(player)) {
            DiseaseCatalog.Disease disease = DiseaseCatalog.byId(id);
            if (disease != null) applyMechanic(player, disease.mechanic(), player.tickCount);
        }
        if (player.tickCount % 20 == 0) DiseaseData.sync(player);
    }

    private static void applyMechanic(ServerPlayer player, DiseaseCatalog.Mechanic mechanic, int tick) {
        switch (mechanic) {
            case SLOW -> player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 45, 0, false, false));
            case WEAKNESS -> player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 45, 0, false, false));
            case HUNGER -> player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 45, 0, false, false));
            case DARKNESS, HALF_SCREEN, EAR_BLACKOUT, BLACKOUT, MIGRAINE, BLINDNESS ->
                    { if (tick % 200 < 35) player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 45, 0, false, false)); }
            case NAUSEA -> { if (tick % 240 < 60) player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 65, 0, false, false)); }
            case COUGH -> { if (tick % 160 < 25) player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 45, 0, false, false)); }
            case MINING_FATIGUE -> player.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 45, 0, false, false));
            case NO_SPRINT -> {
                if (player.isSprinting()) player.setSprinting(false);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 45, 0, false, false));
            }
            case NO_JUMP -> {
                if (player.getDeltaMovement().y > 0.15) player.setDeltaMovement(
                        player.getDeltaMovement().x, 0.15, player.getDeltaMovement().z);
            }
            case SNEEZE -> { if (tick % 180 < 15) player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 30, 0, false, false)); }
            case OFFHAND, LONGER_EFFECTS -> { }
        }
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getHand() == net.minecraft.world.InteractionHand.OFF_HAND
                && event.getEntity() instanceof ServerPlayer player
                && DiseaseData.has(player, "lost_left_arm")) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) DiseaseData.sync(player);
    }
}
