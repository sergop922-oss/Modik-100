package com.randomdiseases;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class TreatDiseasePacket {
    private final String diseaseId;

    public TreatDiseasePacket(String diseaseId) {
        this.diseaseId = diseaseId;
    }

    public static void encode(TreatDiseasePacket packet, FriendlyByteBuf buf) {
        buf.writeUtf(packet.diseaseId, 64);
    }

    public static TreatDiseasePacket decode(FriendlyByteBuf buf) {
        return new TreatDiseasePacket(buf.readUtf(64));
    }

    public static void handle(TreatDiseasePacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            if (!(context.getSender() instanceof ServerPlayer player)) return;
            DiseaseCatalog.Disease disease = DiseaseCatalog.byId(packet.diseaseId);
            if (disease == null || !DiseaseData.has(player, disease.id())) return;

            int needed = disease.tier().price;
            if (player.getInventory().countItem(Items.DIAMOND) < needed) return;

            int remaining = needed;
            for (int slot = 0; slot < player.getInventory().getContainerSize() && remaining > 0; slot++) {
                ItemStack stack = player.getInventory().getItem(slot);
                if (stack.is(Items.DIAMOND)) {
                    int take = Math.min(remaining, stack.getCount());
                    stack.shrink(take);
                    remaining -= take;
                }
            }
            DiseaseData.remove(player, disease.id());
            player.getInventory().setChanged();
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "Вылечено: " + disease.name()), true);
        });
        context.setPacketHandled(true);
    }
}
